use crate::domain::entities::account::PtAccount;
use async_trait::async_trait;
use std::error::Error;

#[async_trait]
pub trait IAccountRepository: Send + Sync {
    async fn get_account_by_cpk(
        &self,
        account_cpk: &str,
    ) -> Result<Option<PtAccount>, Box<dyn Error>>;
}
