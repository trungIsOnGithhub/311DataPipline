#![allow(unused)]
#![allow(clippy::all)]

use chrono::NaiveDateTime;
use diesel::{
    prelude::{Identifiable, Queryable},
    sql_types::Uuid,
};
use serde::{Deserialize, Serialize};
#[derive(Queryable, Debug, Clone)]
#[diesel(primary_key(account_number, plan_id, plan_ver_id, customer_id, trading_group_id))]
pub struct PtAccount {
    pub account_number: String,
    pub plan_id: Uuid,
    pub plan_ver_id: i32,
    pub customer_id: Uuid,
    pub trading_group_id: Uuid,
    pub pass_upgrade_breach_reset_group_id: Option<Uuid>,
    pub competition_id: Option<Uuid>,
    pub account_trading_login: Option<String>,
    pub account_trading_password: Option<String>,
    pub account_type: Option<String>,
    pub account_enabled: bool,
    pub account_archived: bool,
    pub account_created_ts: NaiveDateTime,
    pub account_lastupdate_ts: Option<NaiveDateTime>,
}
