#![allow(unused)]
#![allow(clippy::all)]

use bigdecimal::BigDecimal;
use chrono::NaiveDateTime;
use diesel::{
    prelude::{Identifiable, Queryable},
    sql_types::Uuid,
};
#[derive(Queryable, Debug, Clone)]
#[diesel(primary_key(account_number, plan_id, plan_ver_id, customer_id, trading_group_id))]
pub struct PtAccountDetail {
    pub account_number: String,
    pub plan_id: Uuid,
    pub plan_ver_id: i32,
    pub customer_id: Uuid,
    pub trading_group_id: Uuid,
    pub order_id: Option<Uuid>,
    pub account_display_name: Option<String>,
    pub account_current_balance: Option<BigDecimal>,
    pub account_current_swaps: Option<BigDecimal>,
    pub account_current_commissions: Option<BigDecimal>,
    pub account_current_profit: Option<BigDecimal>,
    pub account_current_equity: Option<BigDecimal>,
    pub account_prev_equity: Option<BigDecimal>,
    pub account_prev_balance: Option<BigDecimal>,
    pub account_daily_loss: Option<BigDecimal>,
    pub account_total_loss: Option<BigDecimal>,
    pub account_breached: Option<bool>,
    pub account_passed: Option<bool>,
    pub account_upgraded: Option<bool>,
    pub account_resetted: Option<bool>,
    pub account_withdrawal_allowed: Option<bool>,
    pub account_hit_profit_target: Option<bool>,
    pub account_visible_leaderboard: Option<bool>,
    pub account_last_history_sync: Option<NaiveDateTime>,
    pub account_last_order_date_sync: Option<NaiveDateTime>,
    pub account_last_trade_day_date_sync: Option<NaiveDateTime>,
    pub account_unique_trade_day_count: Option<i32>,
    pub account_flow_status: Option<String>,
    pub account_flow_reason: Option<String>,
    pub account_last_status_change: Option<NaiveDateTime>,
}
