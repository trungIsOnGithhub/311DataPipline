// @generated automatically by Diesel CLI.

diesel::table! {
    pt_account (account_number, plan_id, plan_ver_id, customer_id, trading_group_id) {
        #[max_length = 32]
        account_number -> Varchar,
        plan_id -> Uuid,
        plan_ver_id -> Int4,
        customer_id -> Uuid,
        trading_group_id -> Uuid,
        pass_upgrade_breach_reset_group_id -> Nullable<Uuid>,
        competition_id -> Nullable<Uuid>,
        #[max_length = 128]
        account_trading_login -> Nullable<Varchar>,
        #[max_length = 128]
        account_trading_password -> Nullable<Varchar>,
        #[max_length = 32]
        account_type -> Nullable<Varchar>,
        account_enabled -> Bool,
        account_archived -> Bool,
        account_created_ts -> Timestamp,
        account_lastupdate_ts -> Nullable<Timestamp>,
    }
}

diesel::table! {
    pt_account_cash_history (ch_id) {
        ch_id -> Int4,
        #[max_length = 32]
        account_number -> Varchar,
        plan_id -> Uuid,
        plan_ver_id -> Int4,
        customer_id -> Uuid,
        trading_group_id -> Uuid,
        ch_datetime -> Timestamp,
        ch_debt -> Numeric,
        ch_credit -> Numeric,
        ch_balance -> Numeric,
        #[max_length = 32]
        ch_status -> Nullable<Varchar>,
        #[max_length = 256]
        ch_comment -> Nullable<Varchar>,
    }
}

diesel::table! {
    pt_account_details (account_number, plan_id, plan_ver_id, customer_id, trading_group_id) {
        #[max_length = 32]
        account_number -> Varchar,
        plan_id -> Uuid,
        plan_ver_id -> Int4,
        customer_id -> Uuid,
        trading_group_id -> Uuid,
        order_id -> Nullable<Uuid>,
        #[max_length = 64]
        account_display_name -> Nullable<Varchar>,
        account_current_balance -> Nullable<Numeric>,
        account_current_swaps -> Nullable<Numeric>,
        account_current_commissions -> Nullable<Numeric>,
        account_current_profit -> Nullable<Numeric>,
        account_current_equity -> Nullable<Numeric>,
        account_prev_equity -> Nullable<Numeric>,
        account_prev_balance -> Nullable<Numeric>,
        account_daily_loss -> Nullable<Numeric>,
        account_total_loss -> Nullable<Numeric>,
        account_breached -> Nullable<Bool>,
        account_passed -> Nullable<Bool>,
        account_upgraded -> Nullable<Bool>,
        account_resetted -> Nullable<Bool>,
        account_withdrawal_allowed -> Nullable<Bool>,
        account_hit_profit_target -> Nullable<Bool>,
        account_visible_leaderboard -> Nullable<Bool>,
        account_last_history_sync -> Nullable<Timestamp>,
        account_last_order_date_sync -> Nullable<Timestamp>,
        account_last_trade_day_date_sync -> Nullable<Timestamp>,
        account_unique_trade_day_count -> Nullable<Int4>,
        #[max_length = 128]
        account_flow_status -> Nullable<Varchar>,
        #[max_length = 256]
        account_flow_reason -> Nullable<Varchar>,
        account_last_status_change -> Nullable<Timestamp>,
    }
}

diesel::table! {
    pt_account_metric_history (met_id) {
        met_id -> Int4,
        #[max_length = 32]
        account_number -> Varchar,
        plan_id -> Uuid,
        plan_ver_id -> Int4,
        customer_id -> Uuid,
        trading_group_id -> Uuid,
        met_date -> Nullable<Timestamp>,
        met_active_trading_days -> Nullable<Int4>,
        met_current_profit -> Nullable<Numeric>,
        met_current_commission -> Nullable<Numeric>,
        met_current_swaps -> Nullable<Numeric>,
        met_current_balance -> Nullable<Numeric>,
        met_current_equity -> Nullable<Numeric>,
        met_days_since_initial_deposit -> Nullable<Int4>,
        met_prev_equity -> Nullable<Numeric>,
        met_prev_balance -> Nullable<Numeric>,
        met_daily_loss -> Nullable<Numeric>,
        met_total_loss -> Nullable<Numeric>,
        met_enabled -> Nullable<Bool>,
        met_breached -> Nullable<Bool>,
        met_passed -> Nullable<Bool>,
        met_hit_profit_target -> Nullable<Bool>,
        met_last_history_sync -> Nullable<Timestamp>,
        met_last_order_date_sync -> Nullable<Timestamp>,
        met_last_trade_day_date_sync -> Nullable<Timestamp>,
    }
}

diesel::table! {
    pt_account_metric_history_slow (account_number, plan_id, plan_ver_id, customer_id, trading_group_id, met_date) {
        #[max_length = 32]
        account_number -> Varchar,
        plan_id -> Uuid,
        plan_ver_id -> Int4,
        customer_id -> Uuid,
        trading_group_id -> Uuid,
        met_date -> Timestamp,
        met_active_trading_days -> Nullable<Int4>,
        met_current_profit -> Nullable<Numeric>,
        met_current_commission -> Nullable<Numeric>,
        met_current_swaps -> Nullable<Numeric>,
        met_current_balance -> Nullable<Numeric>,
        met_current_equity -> Nullable<Numeric>,
        met_days_since_initial_deposit -> Nullable<Int4>,
        met_prev_equity -> Nullable<Numeric>,
        met_prev_balance -> Nullable<Numeric>,
        met_daily_loss -> Nullable<Numeric>,
        met_total_loss -> Nullable<Numeric>,
        met_enabled -> Nullable<Bool>,
        met_breached -> Nullable<Bool>,
        met_passed -> Nullable<Bool>,
        met_hit_profit_target -> Nullable<Bool>,
        met_last_history_sync -> Nullable<Timestamp>,
        met_last_order_date_sync -> Nullable<Timestamp>,
        met_last_trade_day_date_sync -> Nullable<Timestamp>,
    }
}

diesel::table! {
    pt_account_opentrades (trade_id, account_number, plan_id, plan_ver_id, customer_id, trading_group_id) {
        #[max_length = 32]
        trade_id -> Varchar,
        #[max_length = 32]
        account_number -> Varchar,
        plan_id -> Uuid,
        plan_ver_id -> Int4,
        customer_id -> Uuid,
        trading_group_id -> Uuid,
        #[max_length = 32]
        pat_symbol -> Nullable<Varchar>,
        pat_digits -> Nullable<Int4>,
        pat_cmd -> Nullable<Int4>,
        pat_volume -> Nullable<Int4>,
        pat_open_time -> Nullable<Timestamp>,
        pat_open_price -> Nullable<Numeric>,
        pat_sl -> Nullable<Numeric>,
        pat_tp -> Nullable<Numeric>,
        pat_close_time -> Nullable<Timestamp>,
        pat_expiration -> Nullable<Timestamp>,
        pat_reason -> Nullable<Int4>,
        pat_conv_rate1 -> Nullable<Numeric>,
        pat_conv_rate2 -> Nullable<Numeric>,
        pat_conv_rate3 -> Nullable<Numeric>,
        pat_commission -> Nullable<Numeric>,
        pat_commission_agent -> Nullable<Numeric>,
        pat_swaps -> Nullable<Numeric>,
        pat_close_price -> Nullable<Numeric>,
        pat_profit -> Nullable<Numeric>,
        pat_taxes -> Nullable<Numeric>,
        #[max_length = 128]
        pat_comment -> Nullable<Varchar>,
        pat_balance -> Nullable<Numeric>,
        pat_margin_rate -> Nullable<Numeric>,
        pat_server_timestamp -> Nullable<Timestamp>,
        #[max_length = 32]
        pat_magic -> Nullable<Varchar>,
        pat_created_ts -> Timestamp,
        pat_lastupdate_ts -> Nullable<Timestamp>,
    }
}

diesel::table! {
    pt_account_trades_history (trade_id, account_number, plan_id, plan_ver_id, customer_id, trading_group_id) {
        #[max_length = 32]
        trade_id -> Varchar,
        #[max_length = 32]
        account_number -> Varchar,
        plan_id -> Uuid,
        plan_ver_id -> Int4,
        customer_id -> Uuid,
        trading_group_id -> Uuid,
        #[max_length = 32]
        ath_symbol -> Nullable<Varchar>,
        ath_digits -> Nullable<Int4>,
        ath_cmd -> Nullable<Int4>,
        ath_volume -> Nullable<Int4>,
        ath_open_time -> Nullable<Timestamp>,
        ath_open_price -> Nullable<Numeric>,
        ath_sl -> Nullable<Numeric>,
        ath_tp -> Nullable<Numeric>,
        ath_close_time -> Nullable<Timestamp>,
        ath_expiration -> Nullable<Timestamp>,
        ath_reason -> Nullable<Int4>,
        ath_conv_rate1 -> Nullable<Numeric>,
        ath_conv_rate2 -> Nullable<Numeric>,
        ath_conv_rate3 -> Nullable<Numeric>,
        ath_commission -> Nullable<Numeric>,
        ath_commission_agent -> Nullable<Numeric>,
        ath_swaps -> Nullable<Numeric>,
        ath_close_price -> Nullable<Numeric>,
        ath_profit -> Nullable<Numeric>,
        ath_taxes -> Nullable<Numeric>,
        #[max_length = 128]
        ath_comment -> Nullable<Varchar>,
        ath_balance -> Nullable<Numeric>,
        ath_margin_rate -> Nullable<Numeric>,
        ath_server_timestamp -> Nullable<Timestamp>,
        #[max_length = 32]
        ath_magic -> Nullable<Varchar>,
        ath_created_ts -> Timestamp,
        ath_lastupdate_ts -> Nullable<Timestamp>,
    }
}

diesel::table! {
    pt_account_withdrawal (wd_id) {
        wd_id -> Int4,
        #[max_length = 32]
        account_number -> Varchar,
        plan_id -> Uuid,
        plan_ver_id -> Int4,
        customer_id -> Uuid,
        trading_group_id -> Uuid,
        actioned_by_principal_id -> Nullable<Uuid>,
        payment_method_id -> Nullable<Uuid>,
        wd_datetime -> Timestamp,
        wd_amount -> Numeric,
        wd_final_amount -> Nullable<Numeric>,
        #[max_length = 32]
        wd_status -> Nullable<Varchar>,
        #[max_length = 256]
        wd_comment -> Nullable<Varchar>,
        #[max_length = 1024]
        wd_response_comment -> Nullable<Varchar>,
    }
}

diesel::table! {
    pt_account_withdrawal_details (wdd_id, wd_id) {
        wdd_id -> Int4,
        wd_id -> Int4,
        #[max_length = 256]
        wdd_item_description -> Varchar,
        #[max_length = 256]
        wdd_item_comment -> Nullable<Varchar>,
        wdd_debit -> Nullable<Numeric>,
        wdd_credit -> Nullable<Numeric>,
        wdd_is_credit -> Bool,
        wdd_timedate -> Timestamp,
    }
}

diesel::table! {
    pt_affiliate (affiliate_plan_id, customer_id, referred_customer_id) {
        affiliate_plan_id -> Uuid,
        customer_id -> Uuid,
        referred_customer_id -> Uuid,
    }
}

diesel::table! {
    pt_affiliate_m2m_customer (affiliate_plan_id, customer_id) {
        affiliate_plan_id -> Uuid,
        customer_id -> Uuid,
        #[max_length = 256]
        affiliate_customer_payment_email -> Varchar,
        #[max_length = 512]
        affiliate_customer_website_url -> Nullable<Varchar>,
        #[max_length = 512]
        affiliate_customer_affiliate_url -> Varchar,
        #[max_length = 128]
        affiliate_customer_coupon_code -> Nullable<Varchar>,
        affiliate_customer_discount_amount -> Nullable<Numeric>,
        affiliate_customer_referral_count -> Int4,
        affiliate_customer_coupon_discount -> Nullable<Numeric>,
        affiliate_customer_total_commission_earned -> Numeric,
        affiliate_customer_total_paidout -> Numeric,
        affiliate_customer_available_payout -> Numeric,
        affiliate_customer_revenue_generated -> Numeric,
        #[max_length = 256]
        affiliate_customer_promotional_info -> Nullable<Varchar>,
    }
}

diesel::table! {
    pt_affiliate_plan (affiliate_plan_id) {
        affiliate_plan_id -> Uuid,
        #[max_length = 128]
        affiliate_plan_name -> Varchar,
    }
}

diesel::table! {
    pt_backend_request (request_id) {
        request_id -> Uuid,
        request_timestamp -> Timestamp,
        #[max_length = 32]
        request_handler_id -> Nullable<Varchar>,
        #[max_length = 32]
        request_status -> Varchar,
        #[max_length = 32]
        request_verb -> Varchar,
        #[max_length = 4096]
        request_body -> Nullable<Varchar>,
        #[max_length = 256]
        request_response -> Nullable<Varchar>,
        request_id_next_ok -> Nullable<Uuid>,
        request_id_next_fail -> Nullable<Uuid>,
        request_retry_count -> Int4,
        request_retry_max -> Int4,
        #[max_length = 15]
        request_src_ip -> Nullable<Varchar>,
        #[max_length = 256]
        requester_src_context -> Nullable<Varchar>,
        #[max_length = 256]
        requester_src_url -> Nullable<Varchar>,
        request_expiry -> Nullable<Timestamp>,
    }
}

diesel::table! {
    pt_broker (b_id) {
        b_id -> Uuid,
        #[max_length = 128]
        b_name -> Varchar,
        #[max_length = 512]
        b_website -> Nullable<Varchar>,
        #[max_length = 512]
        b_logo -> Nullable<Varchar>,
    }
}

diesel::table! {
    pt_competition (competition_id) {
        competition_id -> Uuid,
    }
}

diesel::table! {
    pt_customer (customer_id) {
        customer_id -> Uuid,
        #[max_length = 128]
        customer_external_id_1 -> Nullable<Varchar>,
        #[max_length = 128]
        customer_external_id_2 -> Nullable<Varchar>,
        #[max_length = 256]
        customer_email -> Nullable<Varchar>,
        #[max_length = 32]
        customer_title -> Nullable<Varchar>,
        #[max_length = 32]
        customer_first_name -> Nullable<Varchar>,
        #[max_length = 32]
        customer_middle_name -> Nullable<Varchar>,
        #[max_length = 32]
        customer_last_name -> Nullable<Varchar>,
        customer_dob -> Nullable<Timestamp>,
        #[max_length = 32]
        customer_language -> Nullable<Varchar>,
        #[max_length = 16]
        customer_phone -> Nullable<Varchar>,
        #[max_length = 128]
        customer_address_l1 -> Nullable<Varchar>,
        #[max_length = 128]
        customer_address_l2 -> Nullable<Varchar>,
        #[max_length = 128]
        customer_address_l3 -> Nullable<Varchar>,
        #[max_length = 32]
        customer_city -> Nullable<Varchar>,
        #[max_length = 32]
        customer_state -> Nullable<Varchar>,
        #[max_length = 32]
        customer_zip -> Nullable<Varchar>,
        #[max_length = 32]
        customer_country -> Nullable<Varchar>,
        customer_last_kyc_attempt -> Nullable<Timestamp>,
        customer_count_kyc_attempts -> Nullable<Int4>,
        #[max_length = 32]
        customer_status -> Varchar,
        #[max_length = 128]
        customer_external_cred_id -> Nullable<Varchar>,
        #[max_length = 128]
        customer_external_cred_username -> Nullable<Varchar>,
        #[max_length = 128]
        customer_external_cred_secrets -> Nullable<Varchar>,
        #[max_length = 256]
        customer_agreement_id -> Nullable<Varchar>,
        customer_agreement_signed -> Bool,
        #[max_length = 32]
        customer_agreement_ip -> Nullable<Varchar>,
        customer_agreement_ts -> Nullable<Timestamp>,
        #[max_length = 256]
        customer_agreement_legalname -> Nullable<Varchar>,
        #[max_length = 32]
        customer_tournament_nickname -> Nullable<Varchar>,
        customer_archived -> Bool,
        customer_created_ts -> Timestamp,
        customer_lastupdate_ts -> Nullable<Timestamp>,
    }
}

diesel::table! {
    pt_customer_o2o_principal (customer_id, principal_id) {
        customer_id -> Uuid,
        principal_id -> Uuid,
    }
}

diesel::table! {
    pt_customer_payment_method (payment_method_id, customer_id) {
        payment_method_id -> Uuid,
        customer_id -> Uuid,
        #[max_length = 32]
        payment_method_type -> Varchar,
        payment_method_default -> Bool,
        payment_method_verified -> Bool,
        #[max_length = 128]
        payment_method_provider_name -> Nullable<Varchar>,
        #[max_length = 32]
        payment_method_currency -> Nullable<Varchar>,
        #[max_length = 256]
        payment_method_full_name -> Nullable<Varchar>,
        #[max_length = 128]
        payment_method_address_line1 -> Nullable<Varchar>,
        #[max_length = 128]
        payment_method_address_line2 -> Nullable<Varchar>,
        #[max_length = 128]
        payment_method_address_line3 -> Nullable<Varchar>,
        #[max_length = 32]
        payment_method_postcode -> Nullable<Varchar>,
        #[max_length = 32]
        payment_method_state -> Nullable<Varchar>,
        #[max_length = 32]
        payment_method_country -> Nullable<Varchar>,
        #[max_length = 32]
        payment_method_bank_account_type -> Nullable<Varchar>,
        #[max_length = 128]
        payment_method_bank_account -> Nullable<Varchar>,
        #[max_length = 128]
        payment_method_bank_identifier_type -> Nullable<Varchar>,
        #[max_length = 128]
        payment_method_bank_identifier -> Nullable<Varchar>,
        #[max_length = 128]
        payment_method_bank_clearing -> Nullable<Varchar>,
        #[max_length = 64]
        payment_method_bank_iban -> Nullable<Varchar>,
        #[max_length = 128]
        payment_method_bank_address_line1 -> Nullable<Varchar>,
        #[max_length = 128]
        payment_method_bank_address_line2 -> Nullable<Varchar>,
        #[max_length = 128]
        payment_method_bank_address_line3 -> Nullable<Varchar>,
        #[max_length = 32]
        payment_method_bank_postcode -> Nullable<Varchar>,
        #[max_length = 32]
        payment_method_bank_state -> Nullable<Varchar>,
        #[max_length = 32]
        payment_method_bank_country -> Nullable<Varchar>,
        #[max_length = 256]
        payment_method_wallet_address -> Nullable<Varchar>,
        payment_method_archived -> Bool,
        payment_method_created_ts -> Timestamp,
        payment_method_lastupdate_ts -> Nullable<Timestamp>,
    }
}

diesel::table! {
    pt_emails (email_storage_id) {
        email_storage_id -> Uuid,
        customer_id -> Uuid,
        #[max_length = 128]
        email_subject -> Nullable<Varchar>,
        email_timestamp -> Nullable<Timestamp>,
        #[max_length = 128]
        email_to -> Nullable<Varchar>,
        #[max_length = 128]
        email_from -> Nullable<Varchar>,
        #[max_length = 32]
        email_status -> Nullable<Varchar>,
    }
}

diesel::table! {
    pt_feature (feature_id) {
        feature_id -> Uuid,
        #[max_length = 128]
        feature_name -> Varchar,
    }
}

diesel::table! {
    pt_order (order_id) {
        order_id -> Uuid,
        plan_id -> Uuid,
        plan_ver_id -> Int4,
        customer_id -> Uuid,
        #[max_length = 128]
        order_external_id -> Nullable<Varchar>,
        #[max_length = 32]
        order_status -> Varchar,
        order_price -> Numeric,
        order_archived -> Bool,
        order_created_ts -> Timestamp,
        order_lastupdate_ts -> Nullable<Timestamp>,
    }
}

diesel::table! {
    pt_plan (plan_id, plan_ver_id) {
        plan_id -> Uuid,
        plan_ver_id -> Int4,
        plan_type_id -> Uuid,
        trading_group_id -> Uuid,
        product_id -> Uuid,
        pass_upgrade_breach_reset_group_id -> Nullable<Uuid>,
        #[max_length = 256]
        plan_description -> Varchar,
        #[max_length = 512]
        plan_reset_link -> Nullable<Varchar>,
        plan_archived -> Bool,
        plan_created_ts -> Timestamp,
        plan_lastupdate_ts -> Nullable<Timestamp>,
    }
}

diesel::table! {
    pt_plan_details (plan_id, plan_ver_id) {
        plan_id -> Uuid,
        plan_ver_id -> Int4,
        #[max_length = 128]
        plan_external_product_id_1 -> Nullable<Varchar>,
        #[max_length = 128]
        plan_external_product_id_2 -> Nullable<Varchar>,
        plan_price -> Nullable<Numeric>,
        plan_duration_days -> Nullable<Int4>,
        plan_leverage -> Nullable<Numeric>,
        plan_start_balance -> Nullable<Numeric>,
        plan_max_open_lots -> Nullable<Numeric>,
        plan_max_total_loss_limit -> Nullable<Numeric>,
        plan_profit_target -> Nullable<Numeric>,
        plan_profit_share -> Nullable<Numeric>,
        plan_daily_loss_limit -> Nullable<Numeric>,
        plan_upgrade_threshold -> Nullable<Numeric>,
        plan_payout_min_amount -> Nullable<Numeric>,
        plan_payout_min_trading_days -> Nullable<Int4>,
        plan_max_inactivity -> Nullable<Int4>,
        plan_min_trading_days -> Nullable<Int4>,
        plan_first_withdraw_delay -> Nullable<Int4>,
        plan_subsequent_withdraw_delay -> Nullable<Int4>,
        plan_flatten_friday -> Nullable<Bool>,
        plan_require_stoploss -> Nullable<Bool>,
        plan_scale_email -> Nullable<Bool>,
        plan_trading_view -> Nullable<Bool>,
        plan_free_repeat -> Nullable<Bool>,
        plan_refund_on_withdrawal -> Nullable<Bool>,
        #[max_length = 32]
        plan_daily_loss_calc_method -> Nullable<Varchar>,
        #[max_length = 512]
        plan_rules -> Nullable<Varchar>,
        plan_tournament -> Bool,
        #[max_length = 32]
        plan_tournament_status -> Nullable<Varchar>,
        plan_tournament_start_datetime -> Nullable<Timestamp>,
        plan_tournament_end_datetime -> Nullable<Timestamp>,
        plan_tournament_runner_up_limit -> Nullable<Int4>,
        plan_tournament_pool_size -> Nullable<Numeric>,
        plan_tournament_pool_split -> Nullable<Numeric>,
    }
}

diesel::table! {
    pt_plan_m2m_customer (plan_id, plan_ver_id, customer_id) {
        plan_id -> Uuid,
        plan_ver_id -> Int4,
        customer_id -> Uuid,
    }
}

diesel::table! {
    pt_plan_tournament_prizes (plan_id, plan_ver_id, plan_tournament_pos) {
        plan_id -> Uuid,
        plan_ver_id -> Int4,
        plan_tournament_pos -> Int4,
        plan_tournament_pool_percent -> Nullable<Numeric>,
        plan_tournament_fixed_cash -> Nullable<Numeric>,
        #[max_length = 128]
        plan_tournament_other_prize -> Nullable<Varchar>,
        #[max_length = 128]
        plan_tournament_prize_name -> Nullable<Varchar>,
    }
}

diesel::table! {
    pt_plan_types (plan_type_id) {
        plan_type_id -> Uuid,
        #[max_length = 128]
        plan_type_name -> Varchar,
    }
}

diesel::table! {
    pt_plan_visuals (plan_id, plan_ver_id) {
        plan_id -> Uuid,
        plan_ver_id -> Int4,
        #[max_length = 512]
        plan_thumbnail_1 -> Nullable<Varchar>,
        #[max_length = 512]
        plan_thumbnail_2 -> Nullable<Varchar>,
        #[max_length = 512]
        plan_thumbnail_3 -> Nullable<Varchar>,
        #[max_length = 32]
        plan_color_1 -> Nullable<Varchar>,
        #[max_length = 32]
        plan_color_2 -> Nullable<Varchar>,
        #[max_length = 32]
        plan_color_3 -> Nullable<Varchar>,
        #[max_length = 32]
        plan_color_4 -> Nullable<Varchar>,
        #[max_length = 32]
        plan_color_5 -> Nullable<Varchar>,
    }
}

diesel::table! {
    pt_plan_workflow (plan_id, plan_ver_id) {
        plan_id -> Uuid,
        plan_ver_id -> Int4,
        #[max_length = 128]
        plan_workflow_step_name -> Nullable<Varchar>,
        prev_pl_id -> Nullable<Uuid>,
        prev_pl_ver_id -> Nullable<Int4>,
        next_pl_id -> Nullable<Uuid>,
        next_pl_ver_id -> Nullable<Int4>,
    }
}

diesel::table! {
    pt_platform_instance (pi_id) {
        pi_id -> Uuid,
        b_id -> Uuid,
        #[max_length = 2048]
        platform_instance_server_address -> Varchar,
        #[max_length = 512]
        platform_instance_server_url -> Nullable<Varchar>,
        #[max_length = 2048]
        platform_instance_server_secrets -> Nullable<Varchar>,
        platform_instance_day_tick -> Nullable<Timestamp>,
        platform_instance_action_tick -> Nullable<Timestamp>,
        #[max_length = 32]
        platform_instance_node -> Nullable<Varchar>,
        platform_instance_tz -> Nullable<Int4>,
        #[max_length = 512]
        platform_instance_download_url -> Nullable<Varchar>,
        platform_instance_enabled -> Bool,
        platform_instance_live -> Bool,
    }
}

diesel::table! {
    pt_principal (principal_id) {
        principal_id -> Uuid,
        #[max_length = 128]
        principal_name -> Varchar,
        #[max_length = 128]
        principal_secret -> Varchar,
        #[max_length = 256]
        principal_secret_seed -> Varchar,
        #[max_length = 256]
        principal_recovery_token -> Nullable<Varchar>,
        principal_active -> Bool,
        principal_system -> Bool,
        #[max_length = 32]
        principal_product_role -> Nullable<Varchar>,
        #[max_length = 32]
        principal_custaccount_role -> Nullable<Varchar>,
        #[max_length = 32]
        principal_order_role -> Nullable<Varchar>,
        #[max_length = 32]
        principal_withdrawal_role -> Nullable<Varchar>,
        #[max_length = 32]
        principal_system_role -> Nullable<Varchar>,
    }
}

diesel::table! {
    pt_product (product_id) {
        product_id -> Uuid,
        #[max_length = 128]
        product_external_id -> Nullable<Varchar>,
        #[max_length = 128]
        product_name -> Varchar,
        #[max_length = 256]
        product_desc -> Nullable<Varchar>,
        #[max_length = 32]
        product_brand_color -> Nullable<Varchar>,
        #[max_length = 512]
        product_brand_thumb_url -> Nullable<Varchar>,
    }
}

diesel::table! {
    pt_product_m2m_feature (product_id, feature_id) {
        product_id -> Uuid,
        feature_id -> Uuid,
        #[max_length = 128]
        product_feature_value -> Varchar,
        product_feature_order -> Int4,
    }
}

diesel::table! {
    pt_referral_tier (referral_tier_level, affiliate_plan_id, customer_id) {
        referral_tier_level -> Int4,
        affiliate_plan_id -> Uuid,
        customer_id -> Uuid,
        referral_tier_threshold -> Int4,
        referral_tier_payout -> Numeric,
        referral_tier_current_tier -> Bool,
    }
}

diesel::table! {
    pt_referral_tier_template (affiliate_plan_id, referral_tier_level) {
        affiliate_plan_id -> Uuid,
        referral_tier_level -> Int4,
        referral_tier_threshold -> Int4,
        referral_tier_payout -> Numeric,
        referral_tier_default_current_tier -> Bool,
    }
}

diesel::table! {
    pt_session (principal_id, token_text) {
        principal_id -> Uuid,
        #[max_length = 512]
        token_text -> Varchar,
        impersonate_principal_id -> Nullable<Uuid>,
        token_expiry -> Timestamp,
    }
}

diesel::table! {
    pt_staff (staff_id) {
        staff_id -> Uuid,
        #[max_length = 32]
        staff_first_name -> Nullable<Varchar>,
        #[max_length = 32]
        staff_last_name -> Nullable<Varchar>,
        #[max_length = 256]
        staff_email -> Nullable<Varchar>,
        #[max_length = 32]
        staff_department -> Nullable<Varchar>,
    }
}

diesel::table! {
    pt_staff_o2o_principal (staff_id, principal_id) {
        staff_id -> Uuid,
        principal_id -> Uuid,
    }
}

diesel::table! {
    pt_system_audit (audit_serial, audit_timestamp, audit_principal_id) {
        audit_serial -> Int4,
        audit_timestamp -> Timestamp,
        audit_principal_id -> Uuid,
        #[max_length = 15]
        audit_ip_address -> Varchar,
        #[max_length = 128]
        audit_action -> Varchar,
        #[max_length = 4096]
        audit_action_details -> Varchar,
    }
}

diesel::table! {
    pt_system_country (country_iso_symbol) {
        #[max_length = 32]
        country_iso_symbol -> Varchar,
        #[max_length = 128]
        country_name -> Varchar,
        #[max_length = 32]
        country_currency_symbol -> Varchar,
        country_enabled -> Bool,
    }
}

diesel::table! {
    pt_system_currency (currency_symbol) {
        #[max_length = 32]
        currency_symbol -> Varchar,
        #[max_length = 128]
        currency_name -> Varchar,
        currency_bank -> Bool,
        currency_crypto -> Bool,
        currency_enabled -> Bool,
    }
}

diesel::table! {
    pt_system_settings (sys_key) {
        #[max_length = 128]
        sys_key -> Varchar,
        #[max_length = 8192]
        sys_value -> Nullable<Varchar>,
    }
}

diesel::table! {
    pt_system_state (state_iso_symbol, state_iso_country) {
        #[max_length = 32]
        state_iso_symbol -> Varchar,
        #[max_length = 32]
        state_iso_country -> Varchar,
        #[max_length = 128]
        state_name -> Varchar,
        state_enabled -> Bool,
    }
}

diesel::table! {
    pt_trading_group (trading_group_id) {
        trading_group_id -> Uuid,
        #[max_length = 128]
        trading_group_server_id -> Varchar,
        #[max_length = 128]
        trading_group_name -> Varchar,
        pi_id -> Uuid,
    }
}

diesel::joinable!(pt_account -> pt_competition (competition_id));
diesel::joinable!(pt_account_details -> pt_order (order_id));
diesel::joinable!(pt_account_withdrawal -> pt_principal (actioned_by_principal_id));
diesel::joinable!(pt_account_withdrawal_details -> pt_account_withdrawal (wd_id));
diesel::joinable!(pt_affiliate -> pt_customer (referred_customer_id));
diesel::joinable!(pt_affiliate_m2m_customer -> pt_affiliate_plan (affiliate_plan_id));
diesel::joinable!(pt_affiliate_m2m_customer -> pt_customer (customer_id));
diesel::joinable!(pt_customer_o2o_principal -> pt_customer (customer_id));
diesel::joinable!(pt_customer_o2o_principal -> pt_principal (principal_id));
diesel::joinable!(pt_customer_payment_method -> pt_customer (customer_id));
diesel::joinable!(pt_emails -> pt_customer (customer_id));
diesel::joinable!(pt_plan -> pt_plan_types (plan_type_id));
diesel::joinable!(pt_plan -> pt_product (product_id));
diesel::joinable!(pt_plan_m2m_customer -> pt_customer (customer_id));
diesel::joinable!(pt_platform_instance -> pt_broker (b_id));
diesel::joinable!(pt_product_m2m_feature -> pt_feature (feature_id));
diesel::joinable!(pt_product_m2m_feature -> pt_product (product_id));
diesel::joinable!(pt_referral_tier_template -> pt_affiliate_plan (affiliate_plan_id));
diesel::joinable!(pt_staff_o2o_principal -> pt_principal (principal_id));
diesel::joinable!(pt_staff_o2o_principal -> pt_staff (staff_id));
diesel::joinable!(pt_system_audit -> pt_principal (audit_principal_id));
diesel::joinable!(pt_trading_group -> pt_platform_instance (pi_id));

diesel::allow_tables_to_appear_in_same_query!(
    pt_account,
    pt_account_cash_history,
    pt_account_details,
    pt_account_metric_history,
    pt_account_metric_history_slow,
    pt_account_opentrades,
    pt_account_trades_history,
    pt_account_withdrawal,
    pt_account_withdrawal_details,
    pt_affiliate,
    pt_affiliate_m2m_customer,
    pt_affiliate_plan,
    pt_backend_request,
    pt_broker,
    pt_competition,
    pt_customer,
    pt_customer_o2o_principal,
    pt_customer_payment_method,
    pt_emails,
    pt_feature,
    pt_order,
    pt_plan,
    pt_plan_details,
    pt_plan_m2m_customer,
    pt_plan_tournament_prizes,
    pt_plan_types,
    pt_plan_visuals,
    pt_plan_workflow,
    pt_platform_instance,
    pt_principal,
    pt_product,
    pt_product_m2m_feature,
    pt_referral_tier,
    pt_referral_tier_template,
    pt_session,
    pt_staff,
    pt_staff_o2o_principal,
    pt_system_audit,
    pt_system_country,
    pt_system_currency,
    pt_system_settings,
    pt_system_state,
    pt_trading_group,
);