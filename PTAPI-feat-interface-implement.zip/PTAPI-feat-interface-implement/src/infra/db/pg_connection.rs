use std::env;

use crate::infra::db::i_connection::IConnection;
use async_trait::async_trait;
use diesel::result::Error;
use diesel::{pg::PgConnection, Connection};
use dotenvy::dotenv;

pub struct PostgresConnection {
    conn: PgConnection,
}

impl PostgresConnection {
    pub fn new() -> Self {
        dotenv().ok();
        let database_url = env::var("DATABASE_URL").expect("DATABASE_URL must be set");
        let conn = PgConnection::establish(&database_url)
            .unwrap_or_else(|_| panic!("Error connecting to {}", database_url));

        Self { conn }
    }
}

#[async_trait]
impl IConnection for PostgresConnection {
    fn get_pg_connection(&mut self) -> &mut PgConnection {
        &mut self.conn
    }

    async fn run_query<F, T>(&mut self, query: F) -> Result<T, Error>
    where
        F: FnOnce(&mut PgConnection) -> Result<T, Error> + Send + 'static,
    {
        let conn = &mut self.conn;
        tokio::task::block_in_place(move || query(conn))
    }
}
