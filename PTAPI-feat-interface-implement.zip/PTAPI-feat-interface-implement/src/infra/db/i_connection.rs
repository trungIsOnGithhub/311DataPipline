use async_trait::async_trait;
use diesel::{result::Error, PgConnection};


#[async_trait]
pub trait IConnection {
    fn get_pg_connection(&mut self) -> &mut PgConnection;

    async fn run_query<F, T>(&mut self, query: F) -> Result<T, Error>
    where
        F: FnOnce(&mut PgConnection) -> Result<T, Error> + Send +  'static;
}
