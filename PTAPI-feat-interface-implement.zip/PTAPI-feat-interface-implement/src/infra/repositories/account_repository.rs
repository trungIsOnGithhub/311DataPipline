use crate::domain::entities::account::PtAccount;
use crate::domain::repositories::i_account_repository::IAccountRepository;
use crate::infra::db::i_connection::IConnection;
use crate::infra::db::schema::pt_account::dsl::*;
use async_trait::async_trait;
use diesel::{ExpressionMethods, OptionalExtension, QueryDsl, RunQueryDsl};
use std::error::Error;

pub struct AccountRepository<Db: IConnection> {
    db_conn: Db,
}

#[async_trait]
impl<DbConnection: IConnection> IAccountRepository for AccountRepository<DbConnection> {
    async fn get_account_by_cpk(
        &self,
        account_cpk: &str,
    ) -> Result<Option<PtAccount>, Box<dyn Error>> {
        self.db_conn.run_query(move |conn| {
            // Ensure conn is mutable
            pt_account.filter(account_number.eq(account_cpk))
                .first::<PtAccount>(conn)
                .optional()
        }).await.map_err(|e| Box::new(e) as Box<dyn Error>)
    }
}